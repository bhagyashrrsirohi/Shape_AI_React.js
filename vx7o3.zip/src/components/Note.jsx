import React from "react";

function Note() {
  return  (
  <div className="note">
    <h1> JavaScript and React.js </h1>
    <p> this was an amazing boot camp taken up by Shaurya Sinha.We learn everything from scratch.It was a great opportunity to learn </p>
  </div> );
}
export default Note;